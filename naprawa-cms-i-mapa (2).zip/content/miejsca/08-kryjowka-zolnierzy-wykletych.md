---
numer_punktu: 8
title: "Kryjówka Żołnierzy Wyklętych"
era: "OKRES POWOJENNY"
typ: "MIEJSCE PAMIĘCI / POMNIK"
typ_szczegolowy: "Miejsce pamięci / tablica"
badge: "ul. Poprzeczna 12"
lat: 51.4642
lng: 22.6091
audio: "audio_kryjowka_zolnierzy_wykletych.mp3"
---
_Opis w przygotowaniu._
