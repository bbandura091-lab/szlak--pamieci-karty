---
numer_punktu: 16
title: "Schron Wojskowy i Magazyn Broni"
era: "II WOJNA ŚWIATOWA"
typ: "OBIEKT HISTORYCZNY / ARCHITEKTURA"
typ_szczegolowy: "Obiekt historyczny / architektura"
badge: "ul. Nowa 5"
lat: 51.4555
lng: 22.6001
audio: "audio_schron_wojskowy_i_magazyn_broni.mp3"
---
_Opis w przygotowaniu._
