---
numer_punktu: 10
title: "Pomnik Niepodległości"
era: "II WOJNA ŚWIATOWA"
typ: "MIEJSCE PAMIĘCI / POMNIK"
typ_szczegolowy: "Pomnik / tablica"
badge: "Plac Wolności 1"
lat: 51.457
lng: 22.6012
audio: "audio_pomnik_niepodleglosci.mp3"
---
_Opis w przygotowaniu._
