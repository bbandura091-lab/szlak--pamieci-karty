---
numer_punktu: 12
title: "Siedziba Sztabu BCh"
era: "II WOJNA ŚWIATOWA"
typ: "MIEJSCE PAMIĘCI / POMNIK"
typ_szczegolowy: "Miejsce pamięci / tablica"
badge: "ul. Kościuszki 20"
lat: 51.4611
lng: 22.6068
audio: "audio_siedziba_sztabu_bch.mp3"
---
_Opis w przygotowaniu._
