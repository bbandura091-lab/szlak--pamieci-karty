---
numer_punktu: 5
title: "Dawny Szpital Polowy AK"
era: "II WOJNA ŚWIATOWA"
typ: "OBIEKT HISTORYCZNY / ARCHITEKTURA"
typ_szczegolowy: "Obiekt historyczny / architektura"
badge: "ul. Legionów 2"
lat: 51.4605
lng: 22.605
audio: "audio_dawny_szpital_polowy_ak.mp3"
---
_Opis w przygotowaniu._
