---
numer_punktu: 28
title: "kpt. dr Zbigniew Bartków"
era: "II WOJNA ŚWIATOWA"
typ: "MIEJSCE PAMIĘCI / POMNIK"
typ_szczegolowy: "Miejsce pamięci / tablica"
badge: "ul. Cicha 14, Szpital Powiatowy"
lat: 51.4678
lng: 22.6033
audio: "audio_tablica_zbigniew_bartkow.mp3"
---
Żołnierz Armii Krajowej, harcmistrz ZHP oraz zasłużony powojenny lekarz okulista lubartowskiego szpitala. Osoba niezwykle skromna i oddana służbie drugiemu człowiekowi.
