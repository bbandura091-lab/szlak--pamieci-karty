---
numer_punktu: 11
title: "Drukarnia Podziemna AK"
era: "II WOJNA ŚWIATOWA"
typ: "OBIEKT HISTORYCZNY / ARCHITEKTURA"
typ_szczegolowy: "Obiekt historyczny / architektura"
badge: "ul. Partyzantów 15"
lat: 51.4581
lng: 22.6025
audio: "audio_drukarnia_podziemna_ak.mp3"
---
Związana z sierż. Karolem Skaruchem ps. „Warta” — szefem Biura Informacji i Propagandy Obwodu, odpowiedzialnym za wydawanie i kolportaż podziemnej prasy.
