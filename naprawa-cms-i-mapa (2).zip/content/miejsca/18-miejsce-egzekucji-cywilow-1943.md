---
numer_punktu: 18
title: "Miejsce Egzekucji Cywilów 1943"
era: "II WOJNA ŚWIATOWA"
typ: "MIEJSCE PAMIĘCI / POMNIK"
typ_szczegolowy: "Pomnik / tablica"
badge: "ul. Piaskowa 2"
lat: 51.468
lng: 22.614
audio: "audio_miejsce_egzekucji_cywilow_1943.mp3"
---
_Opis w przygotowaniu._
