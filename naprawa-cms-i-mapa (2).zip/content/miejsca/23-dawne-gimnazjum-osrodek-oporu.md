---
numer_punktu: 23
title: "Dawne Gimnazjum — Ośrodek Oporu"
era: "II WOJNA ŚWIATOWA"
typ: "OBIEKT HISTORYCZNY / ARCHITEKTURA"
typ_szczegolowy: "Obiekt historyczny / architektura"
badge: "ul. Lubelska 10"
lat: 51.4592
lng: 22.6038
audio: "audio_dawne_gimnazjum_osrodek_oporu.mp3"
---
_Opis w przygotowaniu._
