---
numer_punktu: 6
title: "Dom Przejściowy Wołyniaków"
era: "II WOJNA ŚWIATOWA"
typ: "MIEJSCE PAMIĘCI / POMNIK"
typ_szczegolowy: "Miejsce pamięci / tablica"
badge: "ul. Lubelska 34"
lat: 51.4598
lng: 22.6041
audio: "audio_dom_przejsciowy_wolyniakow.mp3"
---
_Opis w przygotowaniu._
