---
numer_punktu: 17
title: "Punkt Zrzutowy Broni"
era: "II WOJNA ŚWIATOWA"
typ: "MIEJSCE PAMIĘCI / POMNIK"
typ_szczegolowy: "Miejsce pamięci / tablica"
badge: "ul. Polna 18"
lat: 51.454
lng: 22.5985
audio: "audio_punkt_zrzutowy_broni.mp3"
---
_Opis w przygotowaniu._
