---
numer_punktu: 15
title: "Symboliczny Grobowiec Żołnierzy Wyklętych"
era: "OKRES POWOJENNY"
typ: "NEKROPOLIA / MOGIŁA"
typ_szczegolowy: "Miejsce pamięci / tablica"
badge: "Cmentarz Parafialny"
lat: 51.4674
lng: 22.6132
audio: "audio_symboliczny_grobowiec_zolnierzy_wykletych.mp3"
---
_Opis w przygotowaniu._
