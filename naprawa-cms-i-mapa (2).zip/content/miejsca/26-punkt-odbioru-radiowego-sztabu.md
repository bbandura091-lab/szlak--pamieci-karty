---
numer_punktu: 26
title: "Punkt Odbioru Radiowego Sztabu"
era: "II WOJNA ŚWIATOWA"
typ: "MIEJSCE PAMIĘCI / POMNIK"
typ_szczegolowy: "Miejsce pamięci / tablica"
badge: "ul. Słowackiego 12"
lat: 51.4615
lng: 22.606
audio: "audio_punkt_odbioru_radiowego_sztabu.mp3"
---
_Opis w przygotowaniu._
