---
numer_punktu: 27
title: "por. Bolesław Mucharski ps. „Lekarz”"
era: "II WOJNA ŚWIATOWA"
typ: "MIEJSCE PAMIĘCI / POMNIK"
typ_szczegolowy: "Miejsce pamięci / tablica"
badge: "ul. Lubelska 97A, Kościół Matki Bożej NP"
lat: 51.4552
lng: 22.6074
audio: "audio_tablica_boleslaw_mucharski.mp3"
---
Dowódca oddziału partyzanckiego AK w Obwodzie Lubartowskim (1914–1945). Walczył z okupantem niemieckim w latach 1941–1945, zamordowany na Zamku Lubelskim 12.04.1945 r. Tablicę ufundowali w 2005 r. żołnierze AK-WiN, wójt i społeczeństwo gminy Lubartów.
