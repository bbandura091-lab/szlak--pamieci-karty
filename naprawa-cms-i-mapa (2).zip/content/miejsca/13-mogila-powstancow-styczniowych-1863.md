---
numer_punktu: 13
title: "Mogiła Powstańców Styczniowych 1863"
era: "POWSTANIE STYCZNIOWE"
typ: "NEKROPOLIA / MOGIŁA"
typ_szczegolowy: "Pomnik / mogiła"
badge: "Cmentarz Parafialny"
lat: 51.4665
lng: 22.612
audio: "audio_mogila_powstancow_styczniowych_1863.mp3"
---
_Opis w przygotowaniu._
