---
numer_punktu: 3
title: "Siedziba Gestapo i Żandarmerii"
era: "II WOJNA ŚWIATOWA"
typ: "OBIEKT HISTORYCZNY / ARCHITEKTURA"
typ_szczegolowy: "Obiekt historyczny / architektura"
badge: "ul. Cmentarna 4"
lat: 51.4631
lng: 22.6081
audio: "audio_siedziba_gestapo_i_zandarmerii.mp3"
---
_Opis w przygotowaniu._
