---
numer_punktu: 22
title: "Lokal Kontaktowy WiN"
era: "OKRES POWOJENNY"
typ: "MIEJSCE PAMIĘCI / POMNIK"
typ_szczegolowy: "Miejsce pamięci / tablica"
badge: "ul. Ogrodowa 4"
lat: 51.4658
lng: 22.6112
audio: "audio_lokal_kontaktowy_win.mp3"
---
_Opis w przygotowaniu._
