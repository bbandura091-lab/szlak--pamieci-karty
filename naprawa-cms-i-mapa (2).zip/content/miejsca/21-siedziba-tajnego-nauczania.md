---
numer_punktu: 21
title: "Siedziba Tajnego Nauczania"
era: "II WOJNA ŚWIATOWA"
typ: "MIEJSCE PAMIĘCI / POMNIK"
typ_szczegolowy: "Miejsce pamięci / tablica"
badge: "ul. Cmentarna 18"
lat: 51.4645
lng: 22.6098
audio: "audio_siedziba_tajnego_nauczania.mp3"
---
Rekomendowane (niepotwierdzone jednoznacznie) powiązanie z ks. kanonikiem Aleksandrem Szulcem ps. „Ina” (1892–1965), kapelanem Obwodu AK i wieloletnim rektorem kościoła OO. Kapucynów, zaangażowanym w tajne nauczanie.
