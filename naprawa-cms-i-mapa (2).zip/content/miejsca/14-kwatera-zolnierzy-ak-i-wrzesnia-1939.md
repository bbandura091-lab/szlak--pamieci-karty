---
numer_punktu: 14
title: "Kwatera Żołnierzy AK i Września 1939"
era: "II WOJNA ŚWIATOWA"
typ: "NEKROPOLIA / MOGIŁA"
typ_szczegolowy: "Miejsce pamięci / tablica"
badge: "Cmentarz Parafialny"
lat: 51.467
lng: 22.6128
audio: "audio_kwatera_zolnierzy_ak_i_wrzesnia_1939.mp3"
---
_Opis w przygotowaniu._
