---
numer_punktu: 9
title: "Posterunek MO i Urząd Bezpieczeństwa"
era: "OKRES POWOJENNY"
typ: "MIEJSCE PAMIĘCI / POMNIK"
typ_szczegolowy: "Miejsce pamięci / tablica"
badge: "ul. Lipowa 3"
lat: 51.465
lng: 22.6105
audio: "audio_posterunek_mo_i_urzad_bezpieczenstwa.mp3"
---
_Opis w przygotowaniu._
