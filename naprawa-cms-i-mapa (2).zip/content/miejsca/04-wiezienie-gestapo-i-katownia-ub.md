---
numer_punktu: 4
title: "Więzienie Gestapo i Katownia UB"
era: "II WOJNA ŚWIATOWA"
typ: "MIEJSCE PAMIĘCI / POMNIK"
typ_szczegolowy: "Miejsce pamięci / tablica"
badge: "ul. Słowackiego 7"
lat: 51.4619
lng: 22.6062
audio: "audio_wiezienie_gestapo_i_katownia_ub.mp3"
---
_Opis w przygotowaniu._
