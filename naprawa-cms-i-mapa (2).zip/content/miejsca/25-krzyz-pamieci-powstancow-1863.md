---
numer_punktu: 25
title: "Krzyż Pamięci Powstańców 1863"
era: "POWSTANIE STYCZNIOWE"
typ: "MIEJSCE PAMIĘCI / POMNIK"
typ_szczegolowy: "Pomnik / tablica"
badge: "Rondo Styczniowe"
lat: 51.469
lng: 22.615
audio: "audio_krzysz_pamieci_powstancow_1863.mp3"
---
_Opis w przygotowaniu._
