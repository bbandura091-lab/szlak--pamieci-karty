---
numer_punktu: 29
title: "Mural 27 WDP AK"
era: "II WOJNA ŚWIATOWA"
typ: "OBIEKT HISTORYCZNY / ARCHITEKTURA"
typ_szczegolowy: "Mural"
badge: "ul. 1 Maja 82, budynek RCEZ"
lat: 51.462
lng: 22.6
audio: "audio_mural_27_wdp_ak.mp3"
---
Największy w mieście mural poświęcony 27. Wołyńskiej Dywizji Piechoty AK, upamiętniający m.in. mjr. Tadeusza Sztumberka-Rychtera ps. „Żegota” i pozostałych oficerów sztabu dywizji.
