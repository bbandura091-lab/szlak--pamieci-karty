---
numer_punktu: 19
title: "Dom Pamięci Ochotników 1920"
era: "WOJNA 1920"
typ: "MIEJSCE PAMIĘCI / POMNIK"
typ_szczegolowy: "Miejsce pamięci / tablica"
badge: "ul. Krótka 1"
lat: 51.46
lng: 22.6045
audio: "audio_dom_pamieci_ochotnikow_1920.mp3"
---
_Opis w przygotowaniu._
