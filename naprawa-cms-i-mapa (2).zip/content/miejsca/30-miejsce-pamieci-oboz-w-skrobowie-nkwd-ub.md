---
numer_punktu: 30
title: "Miejsce pamięci — Obóz w Skrobowie (NKWD/UB)"
era: "OKRES POWOJENNY"
typ: "OBIEKT HISTORYCZNY / ARCHITEKTURA"
typ_szczegolowy: "Miejsce pamięci"
badge: "Skrobów Kolonia"
lat: 51.4628
lng: 22.5498
audio: "audio_oboz_w_skrobowie.mp3"
---
Miejsce obozu internowania żołnierzy Armii Krajowej podstępnie rozbrojonych przez NKWD i UB zaraz po zakończeniu Akcji „Burza” — mimo że to oni wyzwolili miasto.
