---
numer_punktu: 20
title: "Apteka Podziemna i Punkt Opatrunkowy"
era: "II WOJNA ŚWIATOWA"
typ: "OBIEKT HISTORYCZNY / ARCHITEKTURA"
typ_szczegolowy: "Obiekt historyczny / architektura"
badge: "ul. Rynek 8"
lat: 51.4621
lng: 22.6071
audio: "audio_apteka_podziemna_i_punkt_opatrunkowy.mp3"
---
_Opis w przygotowaniu._
