---
numer_punktu: 31
title: "Stacja PKP Lubartów"
era: "OKRES POWOJENNY"
typ: "MIEJSCE PAMIĘCI / POMNIK"
typ_szczegolowy: "Tablica AK i 27 WDP"
badge: "ul. Kolejowa, Dworzec PKP"
lat: 51.4655
lng: 22.6152
audio: "audio_tablica_pkp_lubartow.mp3"
---
_Opis w przygotowaniu._
