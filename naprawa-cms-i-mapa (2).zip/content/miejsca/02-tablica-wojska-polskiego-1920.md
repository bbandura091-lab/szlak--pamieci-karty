---
numer_punktu: 2
title: "Tablica Wojska Polskiego 1920"
era: "WOJNA 1920"
typ: "MIEJSCE PAMIĘCI / POMNIK"
typ_szczegolowy: "Pomnik / tablica"
badge: "Rynek 15 (fasada kościoła)"
lat: 51.4628
lng: 22.6075
audio: "audio_tablica_wojska_polskiego_1920.mp3"
---
_Opis w przygotowaniu._
