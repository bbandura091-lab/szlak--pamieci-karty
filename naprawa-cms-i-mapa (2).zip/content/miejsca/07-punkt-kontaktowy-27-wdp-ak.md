---
numer_punktu: 7
title: "Punkt Kontaktowy 27 WDP AK"
era: "II WOJNA ŚWIATOWA"
typ: "OBIEKT HISTORYCZNY / ARCHITEKTURA"
typ_szczegolowy: "Obiekt historyczny / architektura"
badge: "ul. Cicha 8"
lat: 51.4589
lng: 22.603
audio: "audio_punkt_kontaktowy_27_wdp_ak.mp3"
---
_Opis w przygotowaniu._
