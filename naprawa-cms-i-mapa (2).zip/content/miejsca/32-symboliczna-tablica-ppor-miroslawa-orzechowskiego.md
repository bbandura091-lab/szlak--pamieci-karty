---
numer_punktu: 32
title: "Symboliczna tablica ppor. Mirosława Orzechowskiego"
era: "II WOJNA ŚWIATOWA"
typ: "NEKROPOLIA / MOGIŁA"
typ_szczegolowy: "Miejsce pamięci / tablica (grób nieznany)"
badge: "Cmentarz Parafialny św. Anny (współrzędne przybliżone)"
lat: 51.462753
lng: 22.6028411
audio: "audio_orzechowski.mp3"
---
Pilot myśliwski RAF, 308. Krakowski Dywizjon Myśliwski (ur. 1916 w Lubartowie). Zginął w akcji bojowej nad Kanałem La Manche 22 lipca 1941 r. w wieku 25 lat. Odznaczony Krzyżem Walecznych i Medalem Lotniczym. Grób nieznany — tablicę postawiła matka i rodzeństwo.
