---
numer_punktu: 1
title: "Sztab Marszałka Piłsudskiego 1920"
era: "WOJNA 1920"
typ: "OBIEKT HISTORYCZNY / ARCHITEKTURA"
typ_szczegolowy: "Obiekt historyczny / architektura"
badge: "Rynek 11, Gmach Starostwa"
lat: 51.46234
lng: 22.60789
audio: "audio_sztab_pilsudskiego_1920.mp3"
---
_Opis w przygotowaniu._
