---
numer_punktu: 24
title: "Warsztat Krawiecki — Kryjówka Służb"
era: "II WOJNA ŚWIATOWA"
typ: "MIEJSCE PAMIĘCI / POMNIK"
typ_szczegolowy: "Miejsce pamięci / tablica"
badge: "ul. Szewska 3"
lat: 51.4578
lng: 22.602
audio: "audio_warsztat_krawiecki_kryjowka_sluzb.mp3"
---
_Opis w przygotowaniu._
